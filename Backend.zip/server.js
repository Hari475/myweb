
const express = require('express');
const path = require('path');
const mysql = require('mysql2');
const nodemailer = require('nodemailer');

const app = express();

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, 'frontend')));

// MySQL connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',            // change if needed
  password: 'Dumpala@12',  // your MySQL password
  database: 'mywebsite'    // make sure this DB exists
});

db.connect(err => {
  if (err) {
    console.error('❌ MySQL connection failed:', err);
    return;
  }
  console.log('✅ MySQL connected successfully!');
});

// Nodemailer transporter
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'reddyhari1610@gmail.com',       // your Gmail
    pass: 'rjtw wepx cktq zmbk'     // Gmail App Password
  }
});

// Contact API route
app.post('/api/contact', (req, res) => {
  const { name, email, phone, message } = req.body;

  if (!name || !email || !message) {
    return res.status(400).json({ error: 'Name, Email, and Message are required' });
  }

  // Save to database
  const sql = 'INSERT INTO contacts (name, email, phone, message) VALUES (?, ?, ?, ?)';
  db.query(sql, [name, email, phone, message], (err, result) => {
    if (err) {
      console.error('❌ Database insert error:', err);
      return res.status(500).json({ error: 'Database error' });
    }

    // Email to Admin
    const adminMail = {
      from: '"ConsulTech Website" <reddyhari1610@gmail.com',
      to: 'reddyhari1610@gmail.com', // admin inbox
      subject: '📩 New Contact Form Submission',
      text: `
      New message received:

      Name: ${name}
      Email: ${email}
      Phone: ${phone}
      Message: ${message}
      `
    };

    // Confirmation email to Customer
    const userMail = {
      from: '"ConsulTech Team" <reddyhari1610@gmail.com>',
      to: email,
      subject: '✅ We received your message',
      text: `
      Hi ${name},

      Thank you for contacting ConsulTech!
      We received your message and will get back to you soon.

      Your message:
      "${message}"

      Regards,  
      ConsulTech Team
      `
    };

    // Send both emails
    transporter.sendMail(adminMail, (error, info) => {
      if (error) console.error('❌ Admin email failed:', error);
      else console.log('✅ Admin email sent:', info.response);
    });

    transporter.sendMail(userMail, (error, info) => {
      if (error) console.error('❌ User email failed:', error);
      else console.log('✅ User email sent:', info.response);
    });

    res.json({ success: true, id: result.insertId });
  });
});

// Home route (optional)
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'frontend', 'index.html'));
});

// Start server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
