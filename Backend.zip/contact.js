document.getElementById("contactForm").addEventListener("submit", async (e) => {
  e.preventDefault();

  const data = {
    name: document.getElementById("name").value,
    email: document.getElementById("email").value,
    phone: document.getElementById("phone").value,
    message: document.getElementById("message").value
  };

  const res = await fetch("/api/contact", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data)
  });

  const result = await res.json();
  if (result.success) {
    document.getElementById("response").innerText = "✅ Your message has been sent!";
    document.getElementById("contactForm").reset();
  } else {
    document.getElementById("response").innerText = "❌ Error sending message.";
  }
});

